﻿using System.Data.Common;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.IdentityModel.Tokens;

namespace Labb_3
{
    public class LocalDB : DbContext
    {
        public DbSet<Betyg> Betyg { get; set; }
        public DbSet<Klass> Klasser { get; set; }
        public DbSet<Kurs> Kurser { get; set; }
        public DbSet<Personal> Personal { get; set; }
        public DbSet<Roll> Roller { get; set; }
        public DbSet<RollerPersonal> RollerPersonal { get; set; }
        public DbSet<Student> Studenter { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=localhost;Database=TestDB;User Id=sa;Password=password;Encrypt=False;");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<RollerPersonal>()
                .HasKey(e => new { e.RollID, e.PersonalID });
        }

    }

    public class Betyg
    {
        public int BetygID { get; set; }
        public string? Resultat { get; set; }
        public DateTime Datum { get; set; }
        public int PersonalID { get; set; }
        public int StudentID { get; set; }
        public int KursID { get; set; }
    }

    public class Klass
    {
        public int KlassID { get; set; }
        public int StudentID { get; set; }
    }

    public class Kurs
    {
        public int KursID { get; set; }
        public int StudentID { get; set; }
    }

    public class Personal
    {
        public int PersonalID { get; set; }
        public string? Personnummer { get; set; }
        public string? Förnamn { get; set; }
        public string? Efternamn { get; set; }
    }

    public class Roll
    {
        public int RollID { get; set; }
        public int RollNamn { get; set; }
    }

    public class RollerPersonal
    {
        public int RollID { get; set; }
        public int PersonalID { get; set; }
    }

    public class Student
    {
        public int StudentID { get; set; }
        public string? Personnummer { get; set; }
        public string? Förnamn { get; set; }
        public string? Efternamn { get; set; }
    }

    internal class Program
    {
        private static void Main(string[] args)
        {
            string connectionString = "Server=localhost;Database=TestDB;User Id=sa;Password=password;Encrypt=False;";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                }
                catch (Exception)
                {
                    Console.WriteLine("Kunde inte ansluta till servern.");
                    return;
                }

                bool exit = false;

                while (!exit)
                {
                    PrintMenu();

                    char option = Console.ReadKey(true).KeyChar;

                    switch (option)
                    {
                        case '1':
                            Console.WriteLine("\nVisa personal med specifik roll? y/n");
                            option = Console.ReadKey(true).KeyChar;
                            switch (option)
                            {
                                case 'Y':
                                case 'y':
                                    using (SqlCommand cmd = new SqlCommand("SELECT * FROM Roller ORDER BY RollID", connection))
                                    {
                                        using (SqlDataReader reader = cmd.ExecuteReader())
                                        {
                                            Console.Write("\n");

                                            while (reader.Read())
                                            {
                                                Console.WriteLine($"{reader[0]} {reader[1]}");
                                            }
                                        }
                                    }

                                    Console.Write("\nVälj roll: ");
                                    string? input = Console.ReadLine();
                                    int roleChoice;
                                    Int32.TryParse(input, out roleChoice);

                                    using (SqlCommand cmd = new SqlCommand($"EXEC SelectAllPersonal @Roll = {roleChoice}", connection))
                                    {
                                        using (SqlDataReader reader = cmd.ExecuteReader())
                                        {
                                            Console.Write("\n");

                                            while (reader.Read())
                                            {
                                                Console.WriteLine($"{reader[0]} {reader[1]} {reader[2]} {reader[3]}");
                                            }

                                            Console.WriteLine("\nTryck på valfri tangent för att gå vidare...");
                                            Console.ReadKey(true);                             
                                        }
                                    }
                                    break;
                                case 'N':
                                case 'n':
                                    using (SqlCommand cmd = new SqlCommand($"EXEC SelectAllPersonal", connection))
                                    {
                                        using (SqlDataReader reader = cmd.ExecuteReader())
                                        {
                                            Console.Write("\n");

                                            while (reader.Read())
                                            {
                                                Console.WriteLine($"{reader[0]} {reader[1]} {reader[2]} {reader[3]}");
                                            }

                                            Console.WriteLine("\nTryck på valfri tangent för att gå vidare...");
                                            Console.ReadKey(true);                             
                                        }
                                    }
                                    break;
                                default:
                                    Console.WriteLine($"\n'{option}' är inte ett alternativ.");
                                    break;
                            }
                            break;
                        case '2':
                            using (var context = new LocalDB())
                            {
                                var studenter = context.Studenter.ToList();

                                Console.WriteLine("Sortera efter:\n1) Förnamn.\n2) Efternamn.");
                                option = Console.ReadKey(true).KeyChar;

                                bool lastName;
                                switch (option)
                                {
                                    case '2':
                                        lastName = true;
                                        break;
                                    case '1':
                                    default:
                                        lastName = false;
                                        break;
                                }
                                Console.WriteLine("Sortera efter:\n1) Stigande ordning.\n2) Fallande ordning.");
                                option = Console.ReadKey(true).KeyChar;

                                switch (option)
                                {
                                    case '2':
                                        studenter = lastName
                                            ? studenter.OrderByDescending(e => e.Efternamn).ToList()
                                            : studenter.OrderByDescending(e => e.Förnamn).ToList();
                                        break;
                                    case '1':
                                    default:
                                        studenter = lastName
                                            ? studenter.OrderBy(e => e.Efternamn).ToList()
                                            : studenter.OrderBy(e => e.Förnamn).ToList();
                                        break;
                                }
                                Console.Write("\n");

                                foreach (var student in studenter)
                                {
                                    Console.WriteLine($"{student.Personnummer} {student.Förnamn} {student.Efternamn}");
                                }

                                Console.WriteLine("\nTryck på valfri tangent för att gå vidare...");
                                Console.ReadKey(true);     
                            }
                            break;
                        case '3':
                            Console.WriteLine("\nVälj en klass:");
                            using (var context = new LocalDB())
                            {
                                var klasser = context.Klasser.GroupBy(klass => klass.KlassID).Select(group => group.First()).ToList();

                                foreach (var klass in klasser)
                                {
                                    Console.WriteLine($"Klass: {klass.KlassID}");
                                }

                                string? input = Console.ReadLine();
                                int classChoice;
                                Int32.TryParse(input, out classChoice);

                                var query = from student in context.Studenter
                                            join klass in context.Klasser on student.StudentID equals klass.StudentID
                                            where klass.KlassID == classChoice
                                            select new
                                            {
                                                student.Personnummer,
                                                student.Förnamn,
                                                student.Efternamn,
                                                klass.KlassID
                                            };
                                var students = query.ToList();

                                foreach (var student in students)
                                {
                                    Console.WriteLine($"Klass {student.KlassID}: {student.Personnummer} {student.Förnamn} {student.Efternamn}");
                                }

                                Console.WriteLine("\nTryck på valfri tangent för att gå vidare...");
                                Console.ReadKey(true);    
                            }
                            break;
                        case '4':
                            using (var context = new LocalDB())
                            {
                                DateTime oneMonthAgo = DateTime.Now.AddMonths(-1);

                                var query = from betyg in context.Betyg
                                            join student in context.Studenter on betyg.StudentID equals student.StudentID
                                            where betyg.Datum >= oneMonthAgo
                                            select new
                                            {
                                                student.Förnamn,
                                                student.Efternamn,
                                                betyg.Resultat,
                                                betyg.Datum,
                                                betyg.KursID
                                            };

                                var pastMonthGrades = query.ToList();

                                Console.Write("\n");
                            
                                foreach (var grade in pastMonthGrades)
                                {
                                    Console.WriteLine($"{grade.Förnamn} {grade.Efternamn} Kurs: {grade.KursID} {grade.Resultat} {grade.Datum}");
                                }

                                Console.WriteLine("\nTryck på valfri tangent för att gå vidare...");
                                Console.ReadKey(true);    

                            }
                            break;            
                        case '5':
                            using (var context = new LocalDB())
                            {
                                var result = context.Betyg
                                    .GroupBy(betyg => betyg.KursID)
                                    .Select(grade => new
                                    {
                                        // Ge varje betyg ett motsvarande numeriskt så som U = 0, G = 1 och VG = 2
                                        KursID = grade.Key,
                                        AverageGrade = grade.Average(betyg => betyg.Resultat == "G" ? 1.0 : (betyg.Resultat == "VG" ? 2.0 : 0.0)),
                                        MinGrade = grade.Min(betyg => betyg.Resultat == "G" ? 1 : (betyg.Resultat == "VG" ? 2 : 0)),
                                        MaxGrade = grade.Max(betyg => betyg.Resultat == "G" ? 1 : (betyg.Resultat == "VG" ? 2 : 0))
                                    })
                                    .ToList();

                                foreach (var statistic in result)
                                {
                                    Console.WriteLine($"Kurs: {statistic.KursID} Min: {statistic.MinGrade} Max: {statistic.MaxGrade} Genomsnitt: {statistic.AverageGrade}");
                                }

                                Console.WriteLine("\nTryck på valfri tangent för att gå vidare...");
                                Console.ReadKey(true);
                            }
                            break;  
                        case '6':
                            using (var context = new LocalDB())
                            {
                                string? firstName = "", lastName = "", socialSecurityNumber = "";

                                while (string.IsNullOrEmpty(firstName))
                                {
                                    Console.WriteLine("Ange förnamn:");
                                    firstName = Console.ReadLine();
                                }

                                while (string.IsNullOrEmpty(lastName))
                                {
                                    Console.WriteLine("Ange efternamn:");
                                    lastName = Console.ReadLine();
                                }

                                while (string.IsNullOrEmpty(socialSecurityNumber))
                                {
                                    Console.WriteLine("Ange personnummer:");
                                    socialSecurityNumber = Console.ReadLine();
                                }

                                var newStudent = new Student
                                {
                                    Förnamn = firstName,
                                    Efternamn = lastName,
                                    Personnummer = socialSecurityNumber
                                };

                                context.Studenter.Add(newStudent);
                                context.SaveChanges();
                            }
                            break;  
                        case '7':
                            using (var context = new LocalDB())
                            {
                                string? firstName = "", lastName = "", socialSecurityNumber = "";

                                while (string.IsNullOrEmpty(firstName))
                                {
                                    Console.WriteLine("Ange förnamn:");
                                    firstName = Console.ReadLine();
                                }

                                while (string.IsNullOrEmpty(lastName))
                                {
                                    Console.WriteLine("Ange efternamn:");
                                    lastName = Console.ReadLine();
                                }

                                while (string.IsNullOrEmpty(socialSecurityNumber))
                                {
                                    Console.WriteLine("Ange personnummer:");
                                    socialSecurityNumber = Console.ReadLine();
                                }

                                var newStaff = new Personal
                                {
                                    Förnamn = firstName,
                                    Efternamn = lastName,
                                    Personnummer = socialSecurityNumber
                                };

                                context.Personal.Add(newStaff);
                                context.SaveChanges();
                            }
                            break;  
                        case '8':
                            exit = true;
                            break;         
                        default:
                            Console.WriteLine($"\n'{option}' är inte ett alternativ.");
                            break;
                    }
                }
            }
        }

        static void PrintMenu()
        {
            Console.WriteLine("\nMeny för Skola");
            Console.WriteLine("--------------");
            Console.WriteLine("1) Visa personal.\n2) Visa alla elever.\n3) Visa alla elever i en viss klass.\n4) Visa alla betyg som satts den senaste månaden.\n5) Visa genomsnittligt, högsta och lägsta betyg i alla kurser.\n6) Lägg till ny elev.\n7) Lägg till ny personal.\n8) Avsluta.");
        }
    }
}